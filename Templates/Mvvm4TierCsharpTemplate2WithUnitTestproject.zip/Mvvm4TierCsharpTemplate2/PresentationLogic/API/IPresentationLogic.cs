﻿namespace $safeprojectname$.PresentationLogic.API
{
    public interface IPresentationLogic
    {
        
    }
}