﻿namespace $safeprojectname$.PresentationLogic.API
{
    internal interface IBusinessLogic
    {
        
    }
}