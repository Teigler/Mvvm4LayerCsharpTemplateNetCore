﻿namespace $safeprojectname$.DataAccess.API
{
    internal interface IDataAccess
    {
        
    }
}