﻿namespace $safeprojectname$.DataAccess.API
{
    internal class DataAccess : IDataAccess
    {
        internal DataAccess()
        {

        }
    }
}
