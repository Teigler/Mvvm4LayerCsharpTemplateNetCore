﻿namespace $safeprojectname$.BusinessLogic.API
{
    internal interface IBusinessLogic
    {
        
    }
}