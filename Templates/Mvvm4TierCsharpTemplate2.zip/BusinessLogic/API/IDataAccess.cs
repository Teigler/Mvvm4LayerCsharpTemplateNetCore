﻿namespace $safeprojectname$.BusinessLogic.API
{
    internal interface IDataAccess
    {
        
    }
}